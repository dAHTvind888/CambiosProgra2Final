using System;

namespace BACKEND.DTO.Recibe
{
	public class CredencialesDTO
	{
		public int Carnet { get; set; }

		public string Contrasena { get; set; }
	}
}