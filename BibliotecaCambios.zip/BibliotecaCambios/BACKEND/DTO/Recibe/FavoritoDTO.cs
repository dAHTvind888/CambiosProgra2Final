using System;

namespace BACKEND.DTO.Recibe
{
    public class FavoritoDTO
    {
        public string Titulo { get; set; }

        public int UsuarioID { get; set; }
    }
}